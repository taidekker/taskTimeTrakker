using System;
using LWTechTaskTimeTracker.Models;
using Xunit;

namespace LWTechTaskTimeTracker_Test
{
    public class CategoryTests
    {
        /// Tests correct handling of discription.
        [Fact]
        public void CategoryStringDefaultDescription()
        {
            Category category = new Category();
            Assert.True(category.Description == null);

        }

        [Theory]
        [InlineData("need to go", "for", "need to go for")]
        [InlineData("", "need to go", " need to go")]



        public void CategoryCorrectJointstring(string first, string second, string expected)
        {
            Category category = new Category();
            category.Name = first;
            category.Description = second;

            Assert.True(category.JointString() == expected);

        }

    }

    public class CompletedTaskTests
    {
        [Fact]
        public void CompletedTaskIntegerDefaultID()
        {
            CompletedTask completedTask = new CompletedTask();
            Assert.True(completedTask.Id == 0);

        }


        [Theory]

        [InlineData(200, "CatDescription", "200 CatDescription")]
        [InlineData(455, "SecondDecription", "455 SecondDecription")]



        public void CompletedTaskIntegerDescriptionConcatenateTest(int testInteger, String description, string expected)

        {
            CompletedTask completedTask = new CompletedTask();
            completedTask.Description = description;
            completedTask.Id = testInteger;

            Assert.True(completedTask.IntegerDescriptionConcatenate() == expected);

        }

    }


    public class CreateCompletedTaskViewModelTests
    {

        [Fact]
        public void CreateCompletedTaskViewModelBooleanDefaultIsActive()
        {
            CreateCompletedTaskViewModel createCompletedTaskView = new CreateCompletedTaskViewModel();
            Assert.True(createCompletedTaskView.IsActive == false);

        }

        [Theory]

        [InlineData("2017-3-1", "TaskViewModelDescription", "{3/1/2017 12:00:00 AM} TaskViewModelDescription")]
        [InlineData("2020-3-15", "TaskViewModelDescription", "{3/15/2020 12:00:00 AM} TaskViewModelDescription")]

        public void CreateCompletedTaskViewModelDateTimeDescriptionConcatenateTest(String testDateTime, String TaskViewModelDescription, string expected)

        {
            CreateCompletedTaskViewModel completedTaskViewModel = new CreateCompletedTaskViewModel();
            var isValidDate = DateTime.Parse(testDateTime);
            completedTaskViewModel.dateTime = isValidDate;
            completedTaskViewModel.Description = TaskViewModelDescription;

            Assert.True(completedTaskViewModel.DateTimeDescriptionConcatenate() == expected);

        }

    }
    public class ReminderMessageTest
    {

        [Fact]
        public void ReminderMessageDateTimeDefaultdateTime()
        {
            ReminderMessage reminderMessage = new ReminderMessage();
            Assert.True(reminderMessage.dateTime == default);

        }
        [Theory]

        [InlineData(245, "2017-3-1", "TaskViewModelDescription", "245 {3/1/2017 12:00:00 AM} TaskViewModelDescription")]
        [InlineData(420, "2020-3-15", "TaskViewModelDescription", "420 {3/15/2020 12:00:00 AM} TaskViewModelDescription")]

        public void ReminderMessageIntegerDateTimeMessageConcatenateTest(int testInteger, String testDateTime, String ReminderMessage, string expected)

        {
            ReminderMessage reminderMsg = new ReminderMessage();
            var isValidDate = DateTime.Parse(testDateTime);
            reminderMsg.dateTime = isValidDate;
            reminderMsg.Message = ReminderMessage;
            reminderMsg.Id = testInteger;

            Assert.True(reminderMsg.IntegerDateTimeMessageConcatenate() == expected);

        }


    }
    public class HistoryTests
    {
        [Fact]
        public void HistoryIntegerDefaultID()
        {
            CompletedTask completedTask = new CompletedTask();
            Assert.True(completedTask.Id == 0);

        }


        [Theory]

       // [InlineData(400, "CatDescription", "200 CatDescription")]
       // [InlineData(555, "SecondDecription", "455 SecondDecription")]

        [InlineData(400, "CaDescription", "400 CaDescription")]
        [InlineData(555, "ForthDecription", "555 ForthDecription")]

        public void HistoryIntegerDescriptionTest(int testInteger, String description, string expected)

        {
            History history = new History();
            history.Description = description;
            history.Id = testInteger;

            Assert.True(history.IntegerDescription() == expected);

        }

    }


}



